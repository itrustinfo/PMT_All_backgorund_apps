﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using ProjectManagementTool.Models;
using ProjectManager.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectManagementTool._modal_pages
{
    public partial class View_IssueHistory : System.Web.UI.Page
    {
        DBGetData getdata = new DBGetData();
        TaskUpdate TKUpdate = new TaskUpdate();
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] == null)
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "CLOSE", "<script language='javascript'>parent.location.href=parent.location.href;</script>");
            }
            else
            {
                if (Request.QueryString["Issue_Uid"] != null)
                {
                    IssueHistoryBind();

                    //doc_pre.HRef = "/_modal_pages/preview-issue-docs.aspx?IssueUid=" + Request.QueryString["Issue_Uid"];


                }
            }
        }

        private void IssueHistoryBind()
        {
            lblProject1.Text = getdata.getProjectNameby_ProjectUID(new Guid(Request.QueryString["PrjID"]));
            lblProject.Text = lblProject1.Text;

            DataSet ds = getdata.GetIssueHistory_by_Issue_Uid(new Guid(Request.QueryString["Issue_Uid"]));

            List<tClass3> IssueHistories = new List<tClass3>();

            int r_count = 0;

            if (ds.Tables[0].Rows.Count > 0)
            {
                string docName = "";
                string docName1 = "";
                string doc_path = "";
                string id = "";
                int objCount = 0;
                Boolean flag = true;
                

                while (flag)
                {
                    
                    id = ds.Tables[0].Rows[objCount].ItemArray[6].ToString();
                    docName = "<a class='showDocModal' href='/_modal_pages/preview-pdf-doc.aspx?doc_name=" + ds.Tables[0].Rows[objCount].ItemArray[7].ToString() + ds.Tables[0].Rows[objCount].ItemArray[5].ToString() + "'>" + ds.Tables[0].Rows[objCount].ItemArray[5].ToString() + "</a>";
                    docName1 = ds.Tables[0].Rows[objCount].ItemArray[5].ToString();
                    doc_path = ds.Tables[0].Rows[objCount].ItemArray[5].ToString();

                    for (int j = objCount + 1; j <= ds.Tables[0].Rows.Count - 1; j++)
                    {

                        if (id == ds.Tables[0].Rows[j].ItemArray[6].ToString())
                        {
                            docName = docName + "</br>" + "<a class='showDocModal'  href='/_modal_pages/preview-pdf-doc.aspx?doc_name=" + ds.Tables[0].Rows[j].ItemArray[7].ToString() + ds.Tables[0].Rows[j].ItemArray[5].ToString() + "'>" + ds.Tables[0].Rows[j].ItemArray[5].ToString() + "</a>"; 
                            docName1 = docName1 + " , " + ds.Tables[0].Rows[j].ItemArray[5].ToString() ;

                            objCount = objCount + 1;
                        }
                    }

                    IssueHistories.Add(new tClass3()
                    {
                        count = r_count,
                        description = ds.Tables[0].Rows[objCount].ItemArray[0].ToString(),
                        remarks = ds.Tables[0].Rows[objCount].ItemArray[1].ToString(),
                        issue_user = ds.Tables[0].Rows[objCount].ItemArray[2].ToString(),
                        issue_date = ds.Tables[0].Rows[objCount].ItemArray[3].ToString(),
                        issue_status = ds.Tables[0].Rows[objCount].ItemArray[4].ToString(),
                        doc_name = docName,
                        id = ds.Tables[0].Rows[objCount].ItemArray[6].ToString(),
                        doc_name1 = docName1
                    });

                    objCount = objCount + 1;

                    if (objCount == ds.Tables[0].Rows.Count) flag = false;
                }
            }

            foreach(tClass3 obj in IssueHistories.OrderBy(a => Convert.ToDateTime(a.issue_date)).ToList())
            {
                r_count = r_count + 1;
                obj.count = r_count;
            }

            GrdIssueStatus.DataSource = IssueHistories.OrderBy(a=>Convert.ToDateTime(a.issue_date)).ToList();
            GrdIssueStatus.DataBind();

           
            if (GrdIssueStatus.Rows.Count>0)
            {
                LblIssue.Text = GrdIssueStatus.Rows[0].Cells[1].Text;
                LblUser.Text = getdata.getUserNameby_UID(new Guid(GrdIssueStatus.Rows[0].Cells[2].Text));

                Label2.Text = GrdIssueStatus.Rows[0].Cells[1].Text;
                Label3.Text = getdata.getUserNameby_UID(new Guid(GrdIssueStatus.Rows[0].Cells[2].Text));
            }

            GridView1.DataSource = IssueHistories.OrderBy(a => Convert.ToDateTime(a.issue_date)).ToList();
            GridView1.DataBind();

            GridView1.HeaderRow.Cells[1].Visible = false;
            GridView1.HeaderRow.Cells[2].Visible = false;
           // GridView1.HeaderRow.Cells[7].Visible = false;


        } 
        

        protected void GrdIssueStatus_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[1].Visible = false;
                e.Row.Cells[2].Visible = false;
                e.Row.Cells[3].Text = Convert.ToDateTime(e.Row.Cells[3].Text).ToString("dd-MM-yyyy");
                
            }
        }

       
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
               // e.Row.Cells[1].Visible = false;
               // e.Row.Cells[2].Visible = false;
               // e.Row.Cells[7].Visible = false;
                e.Row.Cells[1].Text = Convert.ToDateTime(e.Row.Cells[1].Text).ToString("dd-MM-yyyy");
                
            }
        }

        private void Obj_grdview_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            return;
        }

          
        protected void GrdIssueStatus_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string IssueStatusUID = e.CommandArgument.ToString();
        }

        protected void GrdIssueStatus_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GrdIssueStatus_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdIssueStatus.PageIndex = e.NewPageIndex;
        }

        protected void LinkDownload_Click(object sender, EventArgs e)
        {
            CreateAndDownloadZipFile(Request.QueryString["Issue_Uid"]);
        }

        protected void CreateAndDownloadZipFile(string issue_uid)
        {
            string zipFolder = Server.MapPath("/Documents/Issues/IssueDocs/");

            if (!Directory.Exists(zipFolder))
                Directory.CreateDirectory(zipFolder);
            else
            {
                // Delete all files from the Directory  
                foreach (string filename in Directory.GetFiles(zipFolder))
                {
                    File.Delete(filename);
                }
            }

            List<DocFile> files = new List<DocFile>();

            List<string> fileNames = new List<string>();

            DataSet ds1 = getdata.GetUploadedIssueDocuments(issue_uid);

            if (ds1.Tables[0].Rows.Count > 0)
            {
                byte[] bytes;
                string filename = "";

                foreach (DataRow r in ds1.Tables[0].Rows)
                {

                    bytes = getdata.DownloadIssueDocument(Convert.ToInt32(r.ItemArray[0].ToString()), out filename);

                    string filepath = Server.MapPath("~/_PreviewLoad/" + filename);

                    BinaryWriter Writer = null;
                    Writer = new BinaryWriter(File.OpenWrite(filepath));

                    // Writer raw data                
                    Writer.Write(bytes);
                    Writer.Flush();
                    Writer.Close();

                    string outPath = zipFolder + "open_" + filename;

                    string getExtension = System.IO.Path.GetExtension(filepath);

                    outPath = outPath.Replace(getExtension, "") + getExtension;

                    getdata.DecryptFile(filepath, outPath);

                    if (files.Where(a => a.Name.Contains(outPath)).Count() == 0)
                        files.Add(new DocFile { Name = outPath, Position = 0 });
                }

            }

            DataSet ds2 = getdata.GetUploadedAllIssueStatusDocuments(issue_uid);

            if (ds2.Tables[0].Rows.Count > 0)
            {
                byte[] bytes;
                string filename = "";


                foreach (DataRow r in ds2.Tables[0].Rows)
                {
                    bytes = getdata.DownloadDocument(r.ItemArray[0].ToString(), out filename);
                    string filepath = Server.MapPath("~/_PreviewLoad/" + Path.GetFileName(filename));

                    BinaryWriter Writer = null;
                    Writer = new BinaryWriter(File.OpenWrite(filepath));

                    // Writer raw data                
                    Writer.Write(bytes);
                    Writer.Flush();
                    Writer.Close();

                    string outPath = zipFolder + r.ItemArray[3].ToString() + "_" + Path.GetFileName(filename);

                    int p = 0;

                    string getExtension = Path.GetExtension(filepath);

                    outPath = outPath.Replace(getExtension, "") + getExtension;

                    getdata.DecryptFile(filepath, outPath);

                    if (r.ItemArray[3].ToString() == "In-Progress") p = 1;

                    DocFile doc_file = new DocFile() { Name = outPath, Position = p };

                    if (files.Where(a => a.Name.Contains(outPath)).Count() == 0)
                        files.Add(doc_file);
                }
            }

            // Save Zip file

            string zipFilePath = Server.MapPath("/Documents/Issues/IssueDocsZip.zip");

            foreach (DocFile item in files.OrderBy(a => a.Position))
            {
                fileNames.Add(item.Name);
            }

            using (Ionic.Zip.ZipFile zip = new Ionic.Zip.ZipFile())
            {
                zip.AddFiles(fileNames, "IssueDocs");//Zip file inside filename  
                zip.Save(zipFilePath);//location and name for creating zip file  
            }

            FileInfo file = new FileInfo(zipFilePath);

            if (file.Exists)
            {
                Response.Clear();

                Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);

                Response.AddHeader("Content-Length", file.Length.ToString());

                Response.ContentType = "application/octet-stream";

                Response.WriteFile(file.FullName);

                Response.End();

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(Page.GetType(), "CLOSE", "<script language='javascript'>alert('File does not exist.');</script>");
            }
        }


        protected void ConvertPDF_Click(object sender, EventArgs e)
        {
            ExporttoPDF(GridView1, 2, "No");
        }

        private void ExporttoPDF(GridView gd, int type, string isPrint)
        {
            try
            {

                DateTime CDate1 = DateTime.Now;
                GridView gdRp = new GridView();
                gdRp = gd;

                int noOfColumns = 0, noOfRows = 0;
                DataTable tbl = null;

                if (gdRp.AutoGenerateColumns)
                {
                    tbl = gdRp.DataSource as DataTable; // Gets the DataSource of the GridView Control.
                    noOfColumns = tbl.Columns.Count;
                    noOfRows = tbl.Rows.Count;
                }
                else
                {
                    noOfColumns = gdRp.Columns.Count;
                    noOfRows = gdRp.Rows.Count;
                }

                float HeaderTextSize = 9;
                float ReportNameSize = 9;
                float ReportTextSize = 9;
                float ApplicationNameSize = 13;
                string ProjectName = getdata.getProjectNameby_ProjectUID(new Guid(Request.QueryString["PrjID"])); 

                

                //if (ProjectName.Length > 30)
                //{
                //    ProjectName = ProjectName.Substring(0, 29) + "..";
                //}

                // Creates a PDF document

                Document document = null;
                //if (LandScape == true)
                //{
                // Sets the document to A4 size and rotates it so that the     orientation of the page is Landscape.
                document = new Document(PageSize.A4.Rotate(), 0, 0, 0, 0);
                //}
                //else
                //{
                //    document = new Document(PageSize.A4, 0, 0, 15, 5);
                //}

                // Creates a PdfPTable with column count of the table equal to no of columns of the gridview or gridview datasource.
                PdfPTable mainTable = new PdfPTable(noOfColumns);

                // Sets the first 4 rows of the table as the header rows which will be repeated in all the pages.
                mainTable.HeaderRows = 6;

                // Creates a PdfPTable with 2 columns to hold the header in the exported PDF.
                PdfPTable headerTable = new PdfPTable(1);

                // Creates a phrase to hold the application name at the left hand side of the header.
                Phrase phApplicationName = new Phrase(Environment.NewLine + "ONTB-BWSSB Stage 5 Project Monitoring Tool", FontFactory.GetFont("Arial", ApplicationNameSize, iTextSharp.text.Font.BOLD));

                mainTable.SetWidths(new float[] { 8, 12, 12, 12, 30});

                // Creates a PdfPCell which accepts a phrase as a parameter.
                PdfPCell clApplicationName = new PdfPCell(phApplicationName);
                // Sets the border of the cell to zero.
                clApplicationName.Border = PdfPCell.NO_BORDER;
                // Sets the Horizontal Alignment of the PdfPCell to left.
                clApplicationName.HorizontalAlignment = Element.ALIGN_CENTER;

                // Creates a phrase to show the current date at the right hand side of the header.
                //Phrase phDate = new Phrase(DateTime.Now.Date.ToString("dd/MM/yyyy"), FontFactory.GetFont("Arial", ApplicationNameSize, iTextSharp.text.Font.NORMAL));

                //// Creates a PdfPCell which accepts the date phrase as a parameter.
                //PdfPCell clDate = new PdfPCell(phDate);
                //// Sets the Horizontal Alignment of the PdfPCell to right.
                //clDate.HorizontalAlignment = Element.ALIGN_RIGHT;
                //// Sets the border of the cell to zero.
                //clDate.Border = PdfPCell.NO_BORDER;

                // Adds the cell which holds the application name to the headerTable.
                headerTable.AddCell(clApplicationName);
                // Adds the cell which holds the date to the headerTable.
                //  headerTable.AddCell(clDate);
                // Sets the border of the headerTable to zero.
                headerTable.DefaultCell.Border = PdfPCell.NO_BORDER;

                // Creates a PdfPCell that accepts the headerTable as a parameter and then adds that cell to the main PdfPTable.
                PdfPCell cellHeader = new PdfPCell(headerTable);
                cellHeader.Border = PdfPCell.NO_BORDER;
                // Sets the column span of the header cell to noOfColumns.
                cellHeader.Colspan = noOfColumns;
                // Adds the above header cell to the table.
                mainTable.AddCell(cellHeader);

                // Creates a phrase which holds the file name.
                Phrase phHeader = new Phrase("Project Name : " + ProjectName, FontFactory.GetFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))); // + " (" + DDLWorkPackage.SelectedItem.Text + ")") ;  ;
                PdfPCell clHeader = new PdfPCell(phHeader);

                clHeader.Colspan = noOfColumns;
                clHeader.Border = PdfPCell.NO_BORDER;
                clHeader.HorizontalAlignment = Element.ALIGN_CENTER;
                mainTable.AddCell(clHeader);

                Phrase phHeader1 = new Phrase("Issue Module", FontFactory.GetFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))); // + " (" + DDLWorkPackage.SelectedItem.Text + ")") ;  ;
                PdfPCell clHeader1 = new PdfPCell(phHeader1);

                clHeader1.Colspan = noOfColumns;
                clHeader1.Border = PdfPCell.NO_BORDER;
                clHeader1.HorizontalAlignment = Element.ALIGN_CENTER;
                mainTable.AddCell(clHeader1);

                // Creates a phrase for a new line.
                Phrase phSpace = new Phrase("\n");
                PdfPCell clSpace = new PdfPCell(phSpace);
                clSpace.Border = PdfPCell.NO_BORDER;
                clSpace.Colspan = noOfColumns;
                mainTable.AddCell(clSpace);

                Phrase phHeader2 = new Phrase("Issue Description :" + LblIssue.Text, FontFactory.GetFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))); // + " (" + DDLWorkPackage.SelectedItem.Text + ")") ;  ;
                               
                PdfPCell clHeader2 = new PdfPCell(phHeader2);

                clHeader2.Colspan = noOfColumns;
                clHeader2.Border = PdfPCell.NO_BORDER;
                clHeader2.HorizontalAlignment = Element.ALIGN_LEFT;
                
                mainTable.AddCell(clHeader2);

                Phrase phHeader3 = new Phrase("Reporting User :" + LblUser.Text + "\n", FontFactory.GetFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))); // + " (" + DDLWorkPackage.SelectedItem.Text + ")") ;  ;
                PdfPCell clHeader3 = new PdfPCell(phHeader3);

                clHeader3.Colspan = noOfColumns;
                clHeader3.Border = PdfPCell.NO_BORDER;
                clHeader3.HorizontalAlignment = Element.ALIGN_LEFT;
                mainTable.AddCell(clHeader3);

                // Creates a phrase for a new line.
                mainTable.AddCell(clSpace);


                // Sets the gridview column names as table headers.
                for (int i = 0; i < noOfColumns; i++)
                {
                    Phrase ph = null;

                    if (gdRp.AutoGenerateColumns)
                    {
                        ph = new Phrase(tbl.Columns[i].ColumnName.Replace("<br/>", Environment.NewLine), FontFactory.GetFont("Arial", HeaderTextSize, iTextSharp.text.Font.BOLD));
                    }
                    else
                    {
                        ph = new Phrase(gdRp.Columns[i].HeaderText.Replace("<br/>", Environment.NewLine), FontFactory.GetFont("Arial", HeaderTextSize, iTextSharp.text.Font.BOLD));
                    }
                    PdfPCell cl = new PdfPCell(ph);
                    if (i == 1)
                    {
                        cl.HorizontalAlignment = Element.ALIGN_LEFT;
                        mainTable.AddCell(cl);
                    }
                    else if (i == 6)
                    {
                        cl.HorizontalAlignment = Element.ALIGN_LEFT;
                        mainTable.AddCell(cl);
                    }
                    else
                    {
                        cl.HorizontalAlignment = Element.ALIGN_CENTER;
                        mainTable.AddCell(cl);
                    }

                }

                // Reads the gridview rows and adds them to the mainTable
                for (int rowNo = 0; rowNo <= noOfRows; rowNo++)
                {
                    if (rowNo != noOfRows)
                    {
                        for (int columnNo = 0; columnNo < noOfColumns; columnNo++)
                        {
                            if (gdRp.AutoGenerateColumns)
                            {
                                string s = gdRp.Rows[rowNo].Cells[columnNo].Text.Trim();
                                Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, iTextSharp.text.Font.NORMAL));
                                PdfPCell cl = new PdfPCell(ph);
                                cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                mainTable.AddCell(cl);
                            }
                            else
                            {
                                if (columnNo == 1)
                                {
                                    if (gdRp.Columns[columnNo] is TemplateField)
                                    {
                                        DataBoundLiteralControl lc = gdRp.Rows[rowNo].Cells[columnNo].Controls[0] as DataBoundLiteralControl;
                                        string s = lc.Text.Trim();
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_LEFT;
                                        mainTable.AddCell(cl);
                                    }
                                    else
                                    {
                                        string s = gdRp.Rows[rowNo].Cells[columnNo].Text.Trim();
                                        s = s.Replace("&nbsp;", "");
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_LEFT;
                                        mainTable.AddCell(cl);
                                    }
                                }
                                else if (columnNo == 3)
                                {
                                    if (gdRp.Columns[columnNo] is TemplateField)
                                    {
                                        DataBoundLiteralControl lc = gdRp.Rows[rowNo].Cells[columnNo].Controls[0] as DataBoundLiteralControl;
                                        string s = lc.Text.Trim();
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                        mainTable.AddCell(cl);
                                    }
                                    else
                                    {
                                        string s = gdRp.Rows[rowNo].Cells[columnNo].Text.Trim();
                                        s = s.Replace("&nbsp;", "");
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                        mainTable.AddCell(cl);
                                    }
                                }
                                else if (columnNo == 4)
                                {
                                    if (gdRp.Columns[columnNo] is TemplateField)
                                    {
                                        DataBoundLiteralControl lc = gdRp.Rows[rowNo].Cells[columnNo].Controls[0] as DataBoundLiteralControl;
                                        string s = lc.Text.Trim();
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                        mainTable.AddCell(cl);
                                    }
                                    else
                                    {
                                        string s = gdRp.Rows[rowNo].Cells[columnNo].Text.Trim();
                                        s = s.Replace("&nbsp;", "");
                                        s = s.Replace(",", "\n");
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                        mainTable.AddCell(cl);
                                    }
                                }

                                else if (columnNo == 6)
                                {
                                    if (gdRp.Columns[columnNo] is TemplateField)
                                    {
                                        DataBoundLiteralControl lc = gdRp.Rows[rowNo].Cells[columnNo].Controls[0] as DataBoundLiteralControl;
                                        string s = lc.Text.Trim();
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_LEFT;
                                        mainTable.AddCell(cl);
                                    }
                                    else
                                    {
                                        string s = gdRp.Rows[rowNo].Cells[columnNo].Text.Trim();
                                        s = s.Replace("&nbsp;", "");
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_LEFT;
                                        mainTable.AddCell(cl);
                                    }
                                }
                                else
                                {
                                    if (gdRp.Columns[columnNo] is TemplateField)
                                    {
                                        DataBoundLiteralControl lc = gdRp.Rows[rowNo].Cells[columnNo].Controls[0] as DataBoundLiteralControl;
                                        string s = lc.Text.Trim();
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                        mainTable.AddCell(cl);
                                    }
                                    else
                                    {
                                        string s = gdRp.Rows[rowNo].Cells[columnNo].Text.Trim();
                                        s = s.Replace("&nbsp;", "");
                                        Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.NORMAL));
                                        PdfPCell cl = new PdfPCell(ph);
                                        cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                        mainTable.AddCell(cl);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if (type == 1)
                        {
                            for (int columnNo = 0; columnNo < noOfColumns; columnNo++)
                            {
                                string s = "Grand Total";
                                if (columnNo == 1)
                                {
                                    Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.BOLD));
                                    PdfPCell cl = new PdfPCell(ph);
                                    cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                    mainTable.AddCell(cl);
                                }
                                else if (columnNo == 2)
                                {
                                    s = ViewState["grandtotalcount"].ToString();// Session["AwardedValue"].ToString();
                                    Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.BOLD));
                                    PdfPCell cl = new PdfPCell(ph);
                                    cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                    mainTable.AddCell(cl);
                                }
                                else if (columnNo == 3)
                                {
                                    s = ViewState["grandtotaldwnldcount"].ToString();// Session["ExpenditureOverallTotal"].ToString();
                                    Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.BOLD));
                                    PdfPCell cl = new PdfPCell(ph);
                                    cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                    mainTable.AddCell(cl);
                                }
                                else if (columnNo == 4)
                                {
                                    s = ViewState["grandtotalviewcount"].ToString();// Session["TargetedOverallTotal"].ToString() + "%";
                                    Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.BOLD));
                                    PdfPCell cl = new PdfPCell(ph);
                                    cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                    mainTable.AddCell(cl);
                                }
                                else if (columnNo == 5)
                                {
                                    s = ViewState["GrandTotalDocumentLinkSent"].ToString();// Session["AchievedOverallTotal"].ToString() + "%";
                                    Phrase ph = new Phrase(s, FontFactory.GetFont("Arial", ReportTextSize, Font.BOLD));
                                    PdfPCell cl = new PdfPCell(ph);
                                    cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                    mainTable.AddCell(cl);
                                }
                                else
                                {
                                    Phrase ph = new Phrase("", FontFactory.GetFont("Arial", ReportTextSize, Font.BOLD));
                                    PdfPCell cl = new PdfPCell(ph);
                                    cl.HorizontalAlignment = Element.ALIGN_CENTER;
                                    mainTable.AddCell(cl);
                                }
                            }
                        }

                    }

                    // Tells the mainTable to complete the row even if any cell is left incomplete.
                    mainTable.CompleteRow();
                }

                // Gets the instance of the document created and writes it to the output stream of the Response object.
                // Gets the instance of the document created and writes it to the output stream of the Response object.
                if (isPrint == "Yes")
                {
                    PdfWriter.GetInstance(document, new FileStream(Server.MapPath("~/RegExcel/printpdf.pdf"), FileMode.Create));
                }
                else
                {
                    PdfWriter.GetInstance(document, Response.OutputStream);
                }
                //PdfWriter.GetInstance(document, new FileStream(Server.MapPath("~") + "mypdf.pdf", FileMode.Create));
                // Creates a footer for the PDF document.
                int len = 174;
                System.Text.StringBuilder time = new System.Text.StringBuilder();
                time.Append(DateTime.Now.ToString("hh:mm tt"));
                time.Append("".PadLeft(len, ' ').Replace(" ", " "));

                iTextSharp.text.Font foot = new iTextSharp.text.Font();
                foot.Size = 10;
                HeaderFooter pdfFooter = new HeaderFooter(new Phrase("Date : " + DateTime.Now.ToString("dd/MM/yyyy") + " Time " + time + "  Page: ", foot), new Phrase(Environment.NewLine + " ", foot));
                pdfFooter.Alignment = Element.ALIGN_CENTER;
                document.Footer = pdfFooter;
                document.Open();
                // Adds the mainTable to the document.
                document.Add(mainTable);
                // Closes the document.
                document.Close();
                if (isPrint == "Yes")
                {
                    Session["Print"] = true;
                    Response.Write("<script>window.open('/RegExcel/PDFPRint.aspx,'_blank');</script>");
                }
                else
                {
                    Response.ContentType = "application/pdf";
                    Response.AddHeader("content-disposition", "attachment;filename=Report_Issues_" + DateTime.Now.Ticks + ".pdf");
                    Response.End();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}