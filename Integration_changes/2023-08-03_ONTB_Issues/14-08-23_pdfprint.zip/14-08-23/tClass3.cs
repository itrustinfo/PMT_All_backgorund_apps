﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagementTool.Models
{
    public class tClass3
    {
        public int count { get; set; }
        public string description { get; set; }
        public string remarks { get; set; }
        public string issue_user { get; set; }
        public string issue_date { get; set; }
        public string issue_status { get; set; }
        public string doc_name { get; set; }
        public string doc_name1 { get; set; }
        public string id { get; set; }
    }
}