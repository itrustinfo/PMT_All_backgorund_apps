﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagementTool.Models
{
    public class tClass1
    {
        public string MonthYear { get; set; }
        public decimal dQuantity { get; set; }
        public decimal dAverage { get; set; }
    }
}