﻿namespace ProjectManager._content_pages.reports
{
    internal class Document
    {
    }
}